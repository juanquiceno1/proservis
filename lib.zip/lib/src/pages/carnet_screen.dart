import 'package:flutter/material.dart';
// import 'package:sizer/sizer.dart';

class CarnetScreen extends StatelessWidget {
  static const String routeName = 'carnet_screen';
  const CarnetScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _content(context)
    );
  }

  Widget _content(BuildContext context) => SingleChildScrollView(
    child: Column(
      children: [
        _appbar(context),
        _card(context),
      ],
    ),
  );

  Widget _appbar(BuildContext context) => SafeArea(
    child: Padding(
      padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
      child: Row(
        children: [
          IconButton(
            onPressed: (){}, 
            icon: Icon(Icons.arrow_back_ios_rounded)
          ),
          Expanded(
            child: Text(
              'Mi Carné',
              style: TextStyle(
                fontSize: 25.0,
                color: Colors.grey,
                fontWeight: FontWeight.bold
              ),
              textAlign: TextAlign.center,
            )
          ),
          IconButton(
            onPressed: (){}, 
            icon: Icon(
              Icons.more_vert_rounded,
              color: Colors.green,
              // size: 15,
            )
          )
        ],
      ),
    ),
  );

  Widget _card(BuildContext context) => Padding(
    padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
    child: Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(50.0)),
      color: Colors.white,
      child: Column(
        children: [
          Stack(
            children: [
              Container(
                width: double.maxFinite,
                decoration: BoxDecoration(
                  color: Colors.green,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(50.0),
                    topRight: Radius.circular(50.0)
                  )
                ),
                child: Padding(
                  padding: EdgeInsets.only(
                    top: 50,
                    bottom: 100
                  ),
                  child: Image.asset(
                    'assets/Logo-Proservis.png',
                    height: 100,
                    width: 100,
                  ),
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Padding(
                  padding: EdgeInsets.only(
                    top: 180
                  ),
                  child: Column(
                    children: [
                      Container(
                        height: 120,
                        width: 120,
                        padding: EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(100)
                        ),
                        child: Container(
                          padding: EdgeInsets.all(3),
                          decoration: BoxDecoration(
                            // color: Colors.green,
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: <Color>[
                                Colors.green,
                                Colors.green,
                                Colors.white,
                                Colors.white
                              ]
                            ),
                            borderRadius: BorderRadius.circular(100)
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(100),
                            child: Image.asset(
                              'assets/woman.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
          _information(context),
          SizedBox(height: 50.0)
        ],
      ),
    ),
  );

  Widget _information(BuildContext context) => Padding(
    padding: EdgeInsets.symmetric(horizontal: 10.0),
    child: Column(
      children: [
        Row(
          children: [
            Expanded(
              child: Padding(
                padding: EdgeInsets.only(right: 20.0),
                child: Text(
                  'Juliana Franco Restrepo',
                  style: TextStyle(
                    fontSize: 25,
                    color: Colors.green,
                    fontWeight: FontWeight.bold
                  ),
                ),
              ),
            ),
            Stack(
              alignment: Alignment.center,
              children: [
                Image.asset(
                  'assets/box-qr.png',
                  height: 120,
                  width: 120,
                ),
                Image.asset(
                  'assets/qr.png',
                  height: 110,
                  width: 110,
                )
              ],
            )
          ],
        )
      ],
    ),
  );
}